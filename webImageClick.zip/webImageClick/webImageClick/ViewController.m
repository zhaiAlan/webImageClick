//
//  ViewController.m
//  webImageClick
//
//  Created by jinxin on 16/2/23.
//  Copyright © 2016年 zhaixingzhi. All rights reserved.
//

#import "ViewController.h"
#import "UIImageView+WebCache.h"
#import "ImageShowViewController.h"
//定义屏幕的宽高，方便后期使用
#define WIDTH [UIScreen mainScreen].bounds.size.width

#define HEIGHT [UIScreen mainScreen].bounds.size.height


@interface ViewController ()<UIWebViewDelegate>
{
    UIView *bgView;
    UIImageView *imgView;
}

@property(nonatomic,copy)NSString *webUrl;
@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.webUrl = @"http://mp.weixin.qq.com/s?__biz=MjM5ODI3ODI4MA==&mid=419865974&idx=1&sn=87323b6832431f7319d09d67da521593&scene=23&srcid=02238HI0Lj6JeYR96WCWDoPl#rd";
//    self.webUrl = @"http://www.58jinxin.com/doc?t=p&roomId=10019002&docId=1450";
    
    
    [self createWeb];
    // Do any additional setup after loading the view, typically from a nib.
}


-(void)createWeb
{
    UIWebView *web = [[UIWebView alloc]initWithFrame:CGRectMake(0, 0,WIDTH  ,HEIGHT)];
    web.backgroundColor = [UIColor redColor];
    NSURL *url = [[NSURL alloc]initWithString:self.webUrl];
    NSURLRequest *request = [[NSURLRequest alloc]initWithURL:url];
    web.scrollView.showsHorizontalScrollIndicator = NO;
    web.delegate = self;
    [web loadRequest:request];
    [self.view addSubview:web];
}

- (BOOL)webView:(UIWebView *)webView shouldStartLoadWithRequest:(NSURLRequest *)request navigationType:(UIWebViewNavigationType)navigationType{
    //将url转换为string
    NSString *picName = [[request URL] absoluteString];
    NSLog(@"picName is %@",picName);
    //hasPrefix 判断创建的字符串内容是否以pic:字符开始
    if ([picName rangeOfString:@"jpeg"].length || [picName rangeOfString:@"jpg"].length || [picName rangeOfString:@"png"].length) {
        [self showBigImage:[picName substringFromIndex:[picName rangeOfString:@"http"].location]];
    }
    
    if ([picName hasPrefix:@"jpeg"]) {
        [self showBigImage:[picName substringFromIndex:4]];
        return NO;
    }else {
        return YES;
    }
}
-(void)webViewDidFinishLoad:(UIWebView *)webView
{
    //调整字号
    NSString *str = @"document.getElementsByTagName('body')[0].style.webkitTextSizeAdjust= '95%'";
    [webView stringByEvaluatingJavaScriptFromString:str];
    
    //js方法遍历图片添加点击事件 返回图片个数
    static  NSString * const jsGetImages =
    @"function getImages(){\
    var objs = document.getElementsByTagName(\"img\");\
    for(var i=0;i<objs.length;i++){\
    objs[i].onclick=function(){\
    document.location=\"myweb:imageClick:\"+this.src;\
    };\
    };\
    return objs.length;\
    };";
    
    [webView stringByEvaluatingJavaScriptFromString:jsGetImages];//注入js方法
    
    //注入自定义的js方法后别忘了调用 否则不会生效（不调用也一样生效了，，，不明白）
     [webView stringByEvaluatingJavaScriptFromString:@"getImages()"];
    //调用js方法
    //    NSLog(@"---调用js方法--%@  %s  jsMehtods_result = %@",self.class,__func__,resurlt);

}

#pragma mark 显示大图片
-(void)showBigImage:(NSString *)imageUrl{
    
    UIImage * image = [UIImage imageWithData:[NSData dataWithContentsOfURL:[NSURL URLWithString:imageUrl]]];
    ImageShowViewController * vc = [[ImageShowViewController alloc]init];
    vc.imageSize = image.size;
    vc.image = image;
    [self.navigationController pushViewController:vc animated:YES];
    
//    //创建灰色透明背景，使其背后内容不可操作
//    bgView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, WIDTH, HEIGHT)];
//    [bgView setBackgroundColor:[UIColor colorWithRed:0.3
//                                               green:0.3
//                                                blue:0.3
//                                               alpha:0.7]];
//    [self.view addSubview:bgView];
//    
//    //创建边框视图
//    UIView *borderView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, WIDTH-20, 240)];
//    //将图层的边框设置为圆脚
//    borderView.layer.cornerRadius = 8;
//    borderView.layer.masksToBounds = YES;
//    //给图层添加一个有色边框
//    borderView.layer.borderWidth = 8;
//    borderView.layer.borderColor = [[UIColor colorWithRed:0.9
//                                                    green:0.9
//                                                     blue:0.9
//                                                    alpha:0.7] CGColor];
//    [borderView setCenter:bgView.center];
//    [bgView addSubview:borderView];
//    
//    //创建关闭按钮
//    UIButton *closeBtn = [UIButton buttonWithType:UIButtonTypeCustom];
//    //    [closeBtn setImage:[UIImage imageNamed:@"close.png"] forState:UIControlStateNormal];
//    closeBtn.backgroundColor = [UIColor redColor];
//    [closeBtn addTarget:self action:@selector(removeBigImage) forControlEvents:UIControlEventTouchUpInside];
//    [closeBtn setFrame:CGRectMake(borderView.frame.origin.x+borderView.frame.size.width-20, borderView.frame.origin.y-6, 26, 27)];
//    [bgView addSubview:closeBtn];
//    
//    //创建显示图像视图
//    imgView = [[UIImageView alloc] initWithFrame:CGRectMake(10, 10, CGRectGetWidth(borderView.frame)-20, CGRectGetHeight(borderView.frame)-20)];
//    imgView.userInteractionEnabled = YES;
//    UIImage * image = [UIImage imageWithData:[NSData dataWithContentsOfURL:[NSURL URLWithString:imageUrl]]];
//    
//    [imgView sd_setImageWithURL:[NSURL URLWithString:imageUrl] placeholderImage:[UIImage imageNamed:@"微信好友@2x"]];
//    [borderView addSubview:imgView];
//    
//    //添加捏合手势
//    [imgView addGestureRecognizer:[[UIPinchGestureRecognizer alloc]initWithTarget:self action:@selector(handlePinch:)]];
    
}
//关闭按钮
-(void)removeBigImage
{
    bgView.hidden = YES;
}

- (void) handlePinch:(UIPinchGestureRecognizer*) recognizer
{
    //缩放:设置缩放比例
    recognizer.view.transform = CGAffineTransformScale(recognizer.view.transform, recognizer.scale, recognizer.scale);
    recognizer.scale = 1;
}



//#pragma mark -
////显示大图片
//-(void)showBigImage:(NSString *)imageName{
//    //创建灰色透明背景，使其背后内容不可操作
//    UIView *bgView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, WIDTH, HEIGHT)];
//    [bgView setBackgroundColor:[UIColor colorWithRed:0.3
//                                               green:0.3
//                                                blue:0.3
//                                               alpha:0.7]];
//    [self.view addSubview:bgView];
//    
//    //创建边框视图
//    UIView *borderView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 100+16, 100+16)];
//    //将图层的边框设置为圆脚
//    borderView.layer.cornerRadius = 8;
//    borderView.layer.masksToBounds = YES;
//    //给图层添加一个有色边框
//    borderView.layer.borderWidth = 8;
//    borderView.layer.borderColor = [[UIColor colorWithRed:0.9
//                                                    green:0.9
//                                                     blue:0.9
//                                                    alpha:0.7] CGColor];
//    [borderView setCenter:bgView.center];
//    [bgView addSubview:borderView];
//    
//    //创建关闭按钮
//    UIButton *closeBtn = [UIButton buttonWithType:UIButtonTypeCustom];
//    [closeBtn setImage:[UIImage imageNamed:@"close.png"] forState:UIControlStateNormal];
//    [closeBtn addTarget:self action:@selector(removeBigImage:) forControlEvents:UIControlEventTouchUpInside];
//    NSLog(@"borderview is %@",borderView);
//    [closeBtn setFrame:CGRectMake(borderView.frame.origin.x+borderView.frame.size.width-20, borderView.frame.origin.y-6, 26, 27)];
//    [bgView addSubview:closeBtn];
//    
//    //创建显示图像视图
//    UIImageView *imgView = [[UIImageView alloc] initWithFrame:CGRectMake(8, 8, 100, 100)];
//    [imgView setImage:[UIImage imageNamed:imageName]];
//    [borderView addSubview:imgView];
//    
//}
//-(void)removeBigImage:(UIButton *)btn
//{
//    NSLog(@"removeBigImage");
//}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
