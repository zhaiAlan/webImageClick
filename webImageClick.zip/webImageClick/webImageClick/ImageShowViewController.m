//
//  ImageShowViewController.m
//  webImageClick
//
//  Created by jinxin on 16/2/24.
//  Copyright © 2016年 zhaixingzhi. All rights reserved.
//

#import "ImageShowViewController.h"

//定义屏幕的宽高，方便后期使用
#define WIDTH [UIScreen mainScreen].bounds.size.width

#define HEIGHT [UIScreen mainScreen].bounds.size.height


@interface ImageShowViewController ()
{
    UIImageView * imageView;
}
@end

@implementation ImageShowViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor blackColor];
    
    UITapGestureRecognizer * tap = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(tapClick)];
    [self.view addGestureRecognizer:tap];
    imageView = [[UIImageView alloc]init];
    imageView.backgroundColor = [UIColor redColor];
    imageView.image = self.image;
    imageView.userInteractionEnabled = YES;
    [self.view addSubview:imageView];
    CGFloat scale = WIDTH / HEIGHT;
    CGFloat imageScale = _imageSize.width/_imageSize.height;
    if (imageScale > scale )
    {
        imageView.frame = CGRectMake(0, (HEIGHT -  WIDTH * imageScale ) /2, WIDTH, WIDTH * imageScale);
    }else
    {
        imageView .frame = CGRectMake((HEIGHT - HEIGHT * imageScale )/2, 0, HEIGHT * imageScale, HEIGHT);
    }
    [imageView addGestureRecognizer:[[UIPinchGestureRecognizer alloc]initWithTarget:self action:@selector(handlePinch:)]];

    
    // Do any additional setup after loading the view.
}
-(void)tapClick
{
    [self.navigationController popToRootViewControllerAnimated:YES];
}
- (void) handlePinch:(UIPinchGestureRecognizer*) recognizer
{
    NSLog(@"pinch");
    
//    recognizer.scale=recognizer.scale-_lastScale+1;
//    
//    imageView .transform=imageView.transform=CGAffineTransformScale(imageView.transform, recognizer.scale,recognizer.scale);
//    
//    _lastScale=recognizer.scale;
    
    //缩放:设置缩放比例
    recognizer.view.transform = CGAffineTransformScale(recognizer.view.transform, recognizer.scale, recognizer.scale);
    recognizer.scale = 1;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
