//
//  ImageShowViewController.h
//  webImageClick
//
//  Created by jinxin on 16/2/24.
//  Copyright © 2016年 zhaixingzhi. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ImageShowViewController : UIViewController
/**此界面的主题名*/
@property(nonatomic,copy)NSString * imageUrl;
@property(nonatomic,assign)CGSize  imageSize;
@property(nonatomic,strong)UIImage *image;

@end
